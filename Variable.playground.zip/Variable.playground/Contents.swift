import UIKit

//Variables

var userName = "Vineet"
//print(userName)

userName = "Bhavana"
print(userName)

// Constant

let isRaining = true



// predefined type

//var myString: String = "50"

//let myNumber: Int = 10

let stringNumber = String(20)

// check if it is working

// stringNumber * 20


// defined Constant : creating a string but not assigning a value
let myVariable : String

// initilization

myVariable = "Test"
myVariable.uppercased()

// operators
// arithmetic
//let sum = 23 + 20
//let result = 32 - sum
//let total = result * 5
//let divide = total / 10

// comparison

1 == 1
2 != 1
2 > 1
1 < 2
2 <= 1

// logical

(1 == 1) && (2 == 2)
(1 == 1) || (2 != 2)
!(1 == 1)



