import UIKit

// traffic light example if statement
var trafficLightColor = "Yellow"

if trafficLightColor == "Red" {
    print("stop")
} else if trafficLightColor == "Yellow" {
    print("caution")
} else if trafficLightColor == "Green" {
        print("Go")
    } else {
        print("invalide color")
    }

// Switch Statement
trafficLightColor = "Yellow"

switch trafficLightColor {
case "Red":
    print("stop")
    
case "Yellow":
    print("caution")
    
case "Green":
    print("Go")
    
default:
    print("invalide color")
    
}

