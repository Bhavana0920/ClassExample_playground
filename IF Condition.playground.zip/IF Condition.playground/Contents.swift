import UIKit

// check if restaurant is open
let isRestaurantOpen = true
if isRestaurantOpen{
   print("Restaurant is open")
}

// if constant value is false
let isRestaurantFound = false
if isRestaurantFound == false{
    print("Restaurant is not found")
}

// checks if a customer is over the drinking age limit

let drinkingAgeLimit = 21
let customerAge = 23

if customerAge < drinkingAgeLimit {
    print("under age limit")
} else {
    print("over age limit")
}

// Another Example
var myAge = 32

if myAge < 30{
    print("30 less")
} else if myAge > 30 && myAge < 40 {
    print("30s")
} else{
    print("40s")
}
