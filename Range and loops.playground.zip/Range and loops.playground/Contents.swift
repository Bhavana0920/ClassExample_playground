import UIKit

let myRange = 10...20

let myRange2 = 10..<20
print("myRange2")

// displaying value using for loop
for value in myRange2{
    print(value)
}

// displaying values by converting to array

let arrayFromRange = Array(myRange2)
print(arrayFromRange)

// for loop
for number in 0...5{
    print(number)
}

// while loop
var y = 0

while y < 50{
    y += 5
    print("y is \(y)")
}
